import type { PutEventsRequestEntry } from '@aws-sdk/client-eventbridge';

import type { BaseEvent } from '../../core/event-envelope/base-event';
import { serializeBaseEvent } from '../../core/event-envelope/serialize-base-event';
import type { EventBridgeAdapterConfig } from './eventbridge-adapter-config';

/** Maps a {@link BaseEvent} to a single PutEvents entry (no side effects). */
export function toPutEventsEntry(
  event: BaseEvent,
  config: Pick<EventBridgeAdapterConfig, 'eventBusName' | 'source' | 'detailType'>,
): PutEventsRequestEntry {
  return {
    EventBusName: config.eventBusName,
    Source: config.source,
    DetailType: config.detailType ?? event.eventType,
    Detail: serializeBaseEvent(event),
  };
}
